# IPO Bazaar — Android build

This folder is a ready-to-build Android project wrapper around your React
app, using [Capacitor](https://capacitorjs.com/). I can't compile the final
`.apk` from inside this chat (that needs the Android SDK + Gradle, which
aren't available here), so these are the exact steps to produce it on your
own machine.

**App name:** IPO BAZAAR
**App ID:** `com.ipobazaar.app` (change this in `capacitor.config.json`
and `android/app/build.gradle` if you want a different package name —
you can't change it after publishing to Play Store)

## What's included

- `src/App.jsx` — your app code, unchanged
- `src/main.jsx`, `index.html`, `vite.config.js` — the minimal web build
  setup Capacitor needs
- `capacitor.config.json` — app name + ID
- `android-res/` — your logo, already resized into every Android icon
  density (see "Applying the icon" below)

## Prerequisites (install once)

- [Node.js](https://nodejs.org/) 18+
- [Android Studio](https://developer.android.com/studio) (includes the
  Android SDK)
- A Java JDK (Android Studio bundles one)

## Build steps

```bash
# 1. Install dependencies
npm install

# 2. Build the web app
npm run build

# 3. Add the Android platform (only needed once)
npx cap add android

# 4. Copy the web build into the Android project
npx cap sync android
```

### Applying the icon

Copy every folder from `android-res/` into
`android/app/src/main/res/`, overwriting the placeholder icons Capacitor
generated:

```bash
cp -r android-res/mipmap-* android/app/src/main/res/
```

This covers the legacy launcher icon (`ic_launcher.png`,
`ic_launcher_round.png`) and the Android 8+ adaptive icon foreground
(`ic_launcher_foreground.png`) at every density. `android-res/play-store-icon-512.png`
is the 512×512 icon Play Console asks for when you publish — it isn't
used by the app itself.

If you'd rather use Android Studio's built-in tool instead: right-click
`android/app/src/main/res` → **New → Image Asset** → pick
`assets/logo-source.png` as the source, which gives you more control
over padding/background if the default crop doesn't look right.

### Producing the APK

```bash
npx cap open android
```

This opens the project in Android Studio. Then:

- **Quick test build:** Build → Build Bundle(s) / APK(s) → Build APK(s).
  The unsigned debug APK lands in
  `android/app/build/outputs/apk/debug/app-debug.apk` — installable on a
  device for testing, but not suitable for the Play Store.
- **Release build (for the Play Store or sharing publicly):** Build →
  Generate Signed Bundle / APK, create (or reuse) a signing key, and
  build a release APK/AAB. Keep that keystore file safe — you need the
  *same* one for every future update to this app.

You can also build from the command line instead of the Android Studio
UI:

```bash
cd android
./gradlew assembleDebug      # debug APK
./gradlew assembleRelease    # release APK (needs signing config set up first)
```

## Updating the app later

Whenever you change `src/App.jsx`:

```bash
npm run build
npx cap sync android
```

Then rebuild the APK in Android Studio as above.
